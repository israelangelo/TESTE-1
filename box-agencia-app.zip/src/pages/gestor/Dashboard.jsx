import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { T, S } from '../../theme/tokens';
import GeometricBackground from '../../components/GeometricBackground';
import SidebarGestor from '../../components/SidebarGestor';

const MENU = [
  { icon: '👥', label: 'Promotores',    rota: '/gestor/promotores' },
  { icon: '🏪', label: 'Lojas',         rota: '/gestor/lojas'      },
  { icon: '🤝', label: 'Clientes',      rota: '/gestor/clientes'   },
  { icon: '📅', label: 'Escala',        rota: '/gestor/escala'     },
  { icon: '📊', label: 'Relatórios',    rota: '/gestor/relatorios' },
  { icon: '🗺️', label: 'Mapa ao Vivo', rota: '/gestor/mapa'       },
  { icon: '⚙️', label: 'Configurações', rota: '/gestor/configuracoes' },
];

export default function GestorDashboard() {
  const { userData, currentUser } = useAuth();
  const navigate = useNavigate();
  const [menuAberto, setMenuAberto] = useState(false);

  const nome = userData?.nome || currentUser?.email?.split('@')[0] || 'Gestor';
  const hoje = new Date().toLocaleDateString('pt-BR', {
    weekday: 'long', day: '2-digit', month: 'long',
  });

  return (
    <div style={{
      minHeight: '100dvh', fontFamily: T.fontBody, color: T.text,
      maxWidth: 480, margin: '0 auto', padding: '52px 16px 40px',
      position: 'relative',
    }}>
      <GeometricBackground />
      <SidebarGestor aberto={menuAberto} onFechar={() => setMenuAberto(false)} />

      {/* ── HEADER ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28, position: 'relative', zIndex: 1 }}>
        <div>
          <p style={{ margin: 0, fontSize: 13, color: T.muted, textTransform: 'capitalize' }}>{hoje}</p>
          <h1 style={{ margin: '4px 0 0', fontFamily: T.fontTitle, fontSize: 32, fontWeight: 900, letterSpacing: -0.5 }}>
            Olá, {nome.split(' ')[0]} 👋
          </h1>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: T.muted }}>Box Agência — Painel do Gestor</p>
        </div>
        <button
          onClick={() => setMenuAberto(true)}
          style={{
            ...S.card, border: 'none', padding: '10px 14px',
            cursor: 'pointer', fontSize: 22,
          }}>
          ☰
        </button>
      </div>

      {/* ── GRID MENU ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, position: 'relative', zIndex: 1 }}>
        {MENU.map((item) => (
          <button
            key={item.rota}
            onClick={() => navigate(item.rota)}
            style={{
              ...S.card, padding: '22px 16px',
              cursor: 'pointer', textAlign: 'left',
              display: 'flex', flexDirection: 'column', gap: 10,
              transition: T.smooth,
              ...(item.label === 'Mapa ao Vivo' ? {
                background: 'rgba(224,104,32,0.10)',
                border: `1px solid rgba(224,104,32,0.3)`,
              } : {}),
            }}>
            <span style={{ fontSize: 28 }}>{item.icon}</span>
            <span style={{
              fontFamily: T.fontTitle, fontSize: 17, fontWeight: 700,
              color: item.label === 'Mapa ao Vivo' ? T.orange : T.text,
            }}>
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
